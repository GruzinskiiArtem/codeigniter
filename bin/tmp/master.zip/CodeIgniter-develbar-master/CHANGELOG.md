## 1.2.1 (2018-06-20)

Fix:

- Hooks, Allow Closure usage.

## 1.2 (2017-01-18)

Fix:

- Profiling database not possible when using PDO

## 1.1 (2017-01-18)

Fix:

- Profiler link not visible on ajax pannel (JS Error)

## 1.0 (2017-03-21)

Changes:

- New Profiler page for Ajax request

## 0.8 (2017-03-16)

Changes:

- New Tab for Ajax request

## 0.7 (2017-03-15)

Changes:

- Database queries display.
- Global Execution time for multiple database queries.
- Display views variables

## 0.6 (2015-05-21)

Changes:

- var_dump function is used instead of print_r() to show configuration and session details.

## 0.5 (2015-05-17)

Bugfixes:

  - Support of HMVC, Overriding core/MY_Loader.php
  - Breaking view when adding config data which contains html tags

## 0.4 (2015-04-22)

Bugfixes:

- Add translation packages for some languages ( French, German, Russian, Italian, Spanish )
- Set the default translation to English if the translantion file does not exists.

